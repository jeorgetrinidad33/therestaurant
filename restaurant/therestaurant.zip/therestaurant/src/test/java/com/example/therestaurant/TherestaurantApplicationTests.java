package com.example.therestaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TherestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
